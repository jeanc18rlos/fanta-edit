# Fanta Launch Card exercise

Open this project folder in Fanta and choose the **Fanta Studio** page. The **Launch Card** frame contains editable text, shapes and nested frames. It uses Arial without bundling a font file.

## Try the project in ten minutes

1. Select **CTA Button** in the layers panel. Change its background from `#FF6B35` to `#FFC857` and watch the orange button turn yellow.
2. Undo the change, then Redo it. Save the project.
3. Open the Code workspace and inspect `pages/fanta-studio/page.fnx`. Find the frame named **CTA Button** and its background color. If you use Git, inspect the diff before committing.
4. Find the text layer named **Headline**. Change `content="Make your\nnext idea real."` to `content="Make your\nnext idea yours."`, preserving its `id` and other properties. Save the source and confirm the canvas shows the new wording.
5. Save the project, close it and reopen the same folder. Confirm the yellow button and new headline remain.
6. Select **Launch Card** and use its export controls to export a PNG. Open the resulting image to check the actual output.

For another attempt, unzip a fresh copy into a different folder. Keep your edited project until you have saved anything you want to retain.

## Use and attribution

The original card artwork and text were prepared for Fanta. You may copy, modify and share that artwork and text for any purpose, with or without attribution. The sample contains no third-party images, icons, music or embedded fonts. Fanta-generated editor support files retain their application license; see `COPYING`.
