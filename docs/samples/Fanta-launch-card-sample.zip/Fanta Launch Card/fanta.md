# Fanta Launch Card design specification

This sample teaches native editing, source inspection and a bounded agent change using one original card. Keep the card small enough to read beside Fanta's inspector and source panel.

## Visual foundations

The main frame is **Launch Card**, 720 × 480, on the **Fanta Studio** page. Its navy surface is `#111C33`; primary text is `#F7F6F0` and secondary text is `#B6C2D3`. Orange accents use `#FF6B35`. The recording variation changes only **CTA Button** to yellow `#FFC857`.

Typography uses Arial from the host system. The **Headline** is 42 px bold with two intentional lines. Body copy is 18 px, the button label is 18 px bold, and supporting labels are 12–13 px. No font file is distributed.

## Editing boundaries

Preserve each existing ID and the complete layer hierarchy. Native and agent color demonstrations target only the background of **CTA Button**, whose **CTA Label** reads “Start creating.” The source demonstration changes only **Headline** from “Make your next idea real.” to “Make your next idea yours.” and retains its line break.

The **Design Tile** and its **Mini Canvas** illustration use only original geometric shapes. Do not add imported imagery, copyrighted assets or music to the sample project.
